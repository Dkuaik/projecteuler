from setuptools import setup

setup(
    name='project_euler_module',
    version='0.1',
    description='Este paquete contiene modulos para resolver problemas de Project Euler, hasta el problema 50',
    author='Enrique Rios Flores',
    author_email='enrq.rios.f@gmail.com',
    packages=['modulo'],
)